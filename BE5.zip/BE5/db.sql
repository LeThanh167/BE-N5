-- tao database
CREATE DATABASE IF NOT EXISTS cay_canh;
USE cay_canh;

-- tao bang user
CREATE TABLE users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('ADMIN', 'USER') NOT NULL DEFAULT 'USER',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- tao bang danh muc
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255)
);

-- tao bang cay canh
CREATE TABLE plants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    description TEXT,

    FOREIGN KEY (category_id)
        REFERENCES categories(id)
);

-- tao bang don hang
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount DECIMAL(12,2) NOT NULL DEFAULT 0,
    final_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    status ENUM('PENDING', 'CONFIRMED', 'SHIPPING', 'COMPLETED', 'CANCELLED') NOT NULL DEFAULT 'PENDING',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
);

-- tao bang chi tiet don hang
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    plant_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(12,2) NOT NULL,

    FOREIGN KEY (order_id)
        REFERENCES orders(id)
        ON DELETE CASCADE,

    FOREIGN KEY (plant_id)
        REFERENCES plants(id)
);

-- them du lieu cho nguoi dung
INSERT INTO users (name, email, password, role)
VALUES
    ('Admin', 'admin@gmail.com', '123456', 'ADMIN'),
    ('Nguyen Van A', 'user1@gmail.com', '123456', 'USER'),
    ('Nguyen Van B', 'user2@gmail.com', '123456', 'USER');

-- them dl cho danh muc
INSERT INTO categories (name, description)
VALUES
    ('Cây để bàn', 'Các loại cây nhỏ để bàn'),
    ('Cây phong thủy', 'Các loại cây phong thủy'),
    ('Cây nội thất', 'Cây dùng trang trí trong nhà');

SELECT *
FROM categories;

-- them dl cho cay canh
INSERT INTO plants
(category_id, name, price, quantity, description)
VALUES
    (1, 'Cây Kim Tiền', 150000, 20, 'Cây cảnh để bàn'),
    (1, 'Cây Sen Đá', 50000, 30, 'Cây nhỏ dễ chăm sóc'),
    (2, 'Cây Lưỡi Hổ', 120000, 15, 'Cây phong thủy'),
    (2, 'Cây Phú Quý', 180000, 10, 'Cây phong thủy trong nhà'),
    (3, 'Cây Trầu Bà', 100000, 25, 'Cây trang trí nội thất');

SELECT *
FROM plants;

# -- kiem tra quan he categories- plants
# -- các quan hệ chính là: users 1-N orders, orders 1-N order_items, plants 1-N order_items, categories 1-N plants.
# SELECT
#     plants.id,
#     plants.name AS ten_cay,
#     categories.name AS danh_muc,
#     plants.price,
#     plants.quantity
# FROM plants
#          JOIN categories
#               ON plants.category_id = categories.id;

-- them dl cho don hnag
INSERT INTO orders
(user_id, total_amount, discount, final_amount, status)
VALUES
    (2, 350000, 0, 350000, 'PENDING'),
    (3, 300000, 20000, 280000, 'CONFIRMED');

SELECT *
FROM orders;


-- them du lieu cho chi tiet don hang
TRUNCATE TABLE order_items;
INSERT INTO order_items
(order_id, plant_id, quantity, price)
VALUES
    (1, 2, 1, 50000),
    (1, 1, 2, 150000),
    (2, 3, 2, 120000),
    (2, 5, 1, 100000);

SELECT *
FROM order_items;