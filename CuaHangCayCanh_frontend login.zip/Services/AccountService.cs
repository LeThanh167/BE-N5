using System.Net.Http.Json;
using System.Text.Json;
using PlantShopMVC.Models;

namespace PlantShopMVC.Services;

public sealed class AccountService
{
    private readonly HttpClient _httpClient;
    private readonly IHttpContextAccessor _httpContextAccessor;

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    public AccountService(HttpClient httpClient, IHttpContextAccessor httpContextAccessor)
    {
        _httpClient = httpClient;
        _httpContextAccessor = httpContextAccessor;
    }

    // MVC -> POST /api/auth/register trong cùng project.
    public async Task<ServiceResult<string>> RegisterAsync(
        string fullName,
        string email,
        string password,
        CancellationToken cancellationToken = default)
    {
        var request = new RegisterRequest
        {
            FullName = fullName.Trim(),
            Email = email.Trim(),
            Password = password
        };

        try
        {
            using var response = await _httpClient.PostAsJsonAsync(
                BuildApiUri("api/auth/register"),
                request,
                JsonOptions,
                cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                return ServiceResult<string>.Fail(
                    await ReadErrorMessageAsync(response, cancellationToken));
            }

            var result = await response.Content.ReadFromJsonAsync<ApiMessageResponse>(
                JsonOptions,
                cancellationToken);

            return ServiceResult<string>.Ok(
                result?.Message ?? "Đăng ký thành công.");
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return ServiceResult<string>.Fail("Máy chủ phản hồi quá thời gian cho phép. Vui lòng thử lại.");
        }
        catch (HttpRequestException)
        {
            return ServiceResult<string>.Fail("Không thể xử lý yêu cầu đăng ký. Vui lòng thử lại.");
        }
        catch (JsonException)
        {
            return ServiceResult<string>.Fail("Dữ liệu trả về từ máy chủ không hợp lệ.");
        }
    }

    // MVC -> POST /api/auth/login trong cùng project.
    public async Task<ServiceResult<LoginResponse>> LoginAsync(
        string email,
        string password,
        CancellationToken cancellationToken = default)
    {
        var request = new LoginRequest
        {
            Email = email.Trim(),
            Password = password
        };

        try
        {
            using var response = await _httpClient.PostAsJsonAsync(
                BuildApiUri("api/auth/login"),
                request,
                JsonOptions,
                cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                return ServiceResult<LoginResponse>.Fail(
                    await ReadErrorMessageAsync(response, cancellationToken));
            }

            var result = await response.Content.ReadFromJsonAsync<LoginResponse>(
                JsonOptions,
                cancellationToken);

            if (result is null || string.IsNullOrWhiteSpace(result.Token))
            {
                return ServiceResult<LoginResponse>.Fail("Thông tin đăng nhập trả về không hợp lệ.");
            }

            return ServiceResult<LoginResponse>.Ok(result);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return ServiceResult<LoginResponse>.Fail("Máy chủ phản hồi quá thời gian cho phép. Vui lòng thử lại.");
        }
        catch (HttpRequestException)
        {
            return ServiceResult<LoginResponse>.Fail("Không thể xử lý yêu cầu đăng nhập. Vui lòng thử lại.");
        }
        catch (JsonException)
        {
            return ServiceResult<LoginResponse>.Fail("Dữ liệu trả về từ máy chủ không hợp lệ.");
        }
    }

    private Uri BuildApiUri(string relativePath)
    {
        var context = _httpContextAccessor.HttpContext
            ?? throw new InvalidOperationException("Không tìm thấy HTTP context hiện tại.");

        var request = context.Request;
        var baseAddress = $"{request.Scheme}://{request.Host}{request.PathBase}/";

        return new Uri(new Uri(baseAddress), relativePath.TrimStart('/'));
    }

    private static async Task<string> ReadErrorMessageAsync(
        HttpResponseMessage response,
        CancellationToken cancellationToken)
    {
        var raw = await response.Content.ReadAsStringAsync(cancellationToken);

        if (string.IsNullOrWhiteSpace(raw))
        {
            return $"Máy chủ trả về lỗi {(int)response.StatusCode}.";
        }

        try
        {
            using var document = JsonDocument.Parse(raw);
            var root = document.RootElement;

            if (root.ValueKind == JsonValueKind.Object &&
                root.TryGetProperty("message", out var message) &&
                message.ValueKind == JsonValueKind.String)
            {
                return message.GetString() ?? "Có lỗi xảy ra.";
            }

            // Lỗi validation của [ApiController] thường nằm trong thuộc tính errors.
            if (root.ValueKind == JsonValueKind.Object &&
                root.TryGetProperty("errors", out var errorsObject) &&
                errorsObject.ValueKind == JsonValueKind.Object)
            {
                foreach (var property in errorsObject.EnumerateObject())
                {
                    if (property.Value.ValueKind != JsonValueKind.Array)
                    {
                        continue;
                    }

                    foreach (var item in property.Value.EnumerateArray())
                    {
                        if (item.ValueKind == JsonValueKind.String)
                        {
                            return item.GetString() ?? "Dữ liệu gửi lên không hợp lệ.";
                        }
                    }
                }
            }
        }
        catch (JsonException)
        {
            // Nếu body không phải JSON thì trả nội dung thô ở dưới.
        }

        return raw.Length > 300 ? raw[..300] : raw;
    }

    private sealed class ApiMessageResponse
    {
        public string Message { get; set; } = string.Empty;
    }
}
