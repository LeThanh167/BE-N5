namespace PlantShopMVC.Services;

public sealed class ServiceResult<T>
{
    public bool Success { get; private init; }
    public T? Data { get; private init; }
    public string? Message { get; private init; }

    public static ServiceResult<T> Ok(T data, string? message = null) => new()
    {
        Success = true,
        Data = data,
        Message = message
    };

    public static ServiceResult<T> Fail(string message) => new()
    {
        Success = false,
        Message = message
    };
}
