using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using PlantShopAPI.Models;

namespace PlantShopAPI.Controllers;

[Route("api/auth")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly IConfiguration _configuration;

    public AuthController(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        IConfiguration configuration)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _configuration = configuration;
    }

    // ===================== ĐĂNG KÝ =====================
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterDto model)
    {
        var email = model.Email.Trim();
        var fullName = model.FullName.Trim();

        var userExists = await _userManager.FindByEmailAsync(email);
        if (userExists is not null)
        {
            return BadRequest(new { message = "Email này đã được sử dụng." });
        }

        var user = new ApplicationUser
        {
            UserName = email,
            Email = email,
            FullName = fullName,
            Role = "USER"
        };

        var result = await _userManager.CreateAsync(user, model.Password);

        if (!result.Succeeded)
        {
            return BadRequest(new { message = VietHoaLoiIdentity(result.Errors) });
        }

        return Ok(new { message = "Đăng ký thành công. Hãy đăng nhập bằng tài khoản vừa tạo." });
    }

    // ===================== ĐĂNG NHẬP =====================
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto model)
    {
        var email = model.Email.Trim();
        var user = await _userManager.FindByEmailAsync(email);

        if (user is null)
        {
            return Unauthorized(new { message = "Email hoặc mật khẩu không đúng." });
        }

        var result = await _signInManager.CheckPasswordSignInAsync(user, model.Password, false);
        if (!result.Succeeded)
        {
            return Unauthorized(new { message = "Email hoặc mật khẩu không đúng." });
        }

        var token = GenerateJwtToken(user);

        return Ok(new
        {
            token,
            email = user.Email,
            fullName = user.FullName,
            role = user.Role
        });
    }

    // ===================== TẠO MÃ ĐĂNG NHẬP JWT =====================
    private string GenerateJwtToken(ApplicationUser user)
    {
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id),
            new Claim(ClaimTypes.Email, user.Email ?? string.Empty),
            new Claim(ClaimTypes.Name, user.FullName ?? string.Empty),
            new Claim(ClaimTypes.Role, user.Role ?? "USER")
        };

        var key = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _configuration["Jwt:Issuer"],
            audience: _configuration["Jwt:Audience"],
            claims: claims,
            expires: DateTime.Now.AddHours(3),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static string VietHoaLoiIdentity(IEnumerable<IdentityError> errors)
    {
        var messages = errors.Select(error => error.Code switch
        {
            "PasswordTooShort" => "Mật khẩu phải có ít nhất 6 ký tự.",
            "PasswordRequiresDigit" => "Mật khẩu phải có ít nhất 1 chữ số.",
            "PasswordRequiresLower" => "Mật khẩu phải có ít nhất 1 chữ thường.",
            "PasswordRequiresUpper" => "Mật khẩu phải có ít nhất 1 chữ hoa.",
            "PasswordRequiresNonAlphanumeric" => "Mật khẩu phải có ít nhất 1 ký tự đặc biệt.",
            "DuplicateEmail" => "Email này đã được sử dụng.",
            "DuplicateUserName" => "Email này đã được sử dụng.",
            "InvalidEmail" => "Email không đúng định dạng.",
            "InvalidUserName" => "Email không hợp lệ.",
            _ => "Không thể tạo tài khoản với thông tin đã nhập."
        }).Distinct();

        return string.Join(" ", messages);
    }
}

public class RegisterDto
{
    [Required(ErrorMessage = "Vui lòng nhập họ và tên.")]
    [StringLength(100, MinimumLength = 2, ErrorMessage = "Họ và tên phải từ 2 đến 100 ký tự.")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập email.")]
    [EmailAddress(ErrorMessage = "Email không đúng định dạng.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập mật khẩu.")]
    public string Password { get; set; } = string.Empty;
}

public class LoginDto
{
    [Required(ErrorMessage = "Vui lòng nhập email.")]
    [EmailAddress(ErrorMessage = "Email không đúng định dạng.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập mật khẩu.")]
    public string Password { get; set; } = string.Empty;
}
