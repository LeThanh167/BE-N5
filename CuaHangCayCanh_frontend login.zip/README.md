# Cửa Hàng Cây Cảnh - Đăng ký / Đăng nhập (.NET 11)

Bản này đã gộp API và MVC vào **một project duy nhất**.

## Chạy project

Mở PowerShell ngay tại thư mục có file `CuaHangCayCanh.csproj`:

```powershell
dotnet restore
dotnet ef database update
dotnet run
```

Sau đó mở:

- Giao diện đăng nhập: `http://localhost:5180/Account/Login`
- Giao diện đăng ký: `http://localhost:5180/Account/Register`
- API đăng ký: `POST http://localhost:5180/api/auth/register`
- API đăng nhập: `POST http://localhost:5180/api/auth/login`

Không cần chạy API ở PowerShell thứ hai nữa.

## MySQL

Kiểm tra `appsettings.json` và sửa `DefaultConnection` cho đúng tài khoản MySQL trên máy.
Nếu MySQL `root` không có mật khẩu, có thể dùng:

```text
Server=localhost;Port=3306;Database=PlantShopDB;User=root;Password=;
```

## Luồng xử lý

```text
Razor View
   ↓
AccountController (MVC)
   ↓
AccountService
   ↓ HTTP nội bộ cùng ứng dụng
/api/auth/register hoặc /api/auth/login
   ↓
AuthController (API)
   ↓
ASP.NET Core Identity + MySQL
```
